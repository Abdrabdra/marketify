self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "beeec1bbb9f404fbd37127f9d0d32684",
    "url": "/index.html"
  },
  {
    "revision": "0670130f57c371de2c1e",
    "url": "/static/css/2.77ffe96b.chunk.css"
  },
  {
    "revision": "b7770b50e0d19ea35203",
    "url": "/static/css/main.95c4d928.chunk.css"
  },
  {
    "revision": "0670130f57c371de2c1e",
    "url": "/static/js/2.b2dcf7ab.chunk.js"
  },
  {
    "revision": "271637ead0c95628afa8dfa315171b23",
    "url": "/static/js/2.b2dcf7ab.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b7770b50e0d19ea35203",
    "url": "/static/js/main.ebde4e5f.chunk.js"
  },
  {
    "revision": "aa26b6bff08a1d447309",
    "url": "/static/js/runtime-main.c6f40c10.js"
  },
  {
    "revision": "38d684ee47566b6d7fb5d743aec61a99",
    "url": "/static/media/01.38d684ee.jpg"
  },
  {
    "revision": "8491142e5f7a2422821cfb0fd37dbdcb",
    "url": "/static/media/0111.8491142e.png"
  },
  {
    "revision": "ec75f7ff9ddbd2e7e5c46b004437a602",
    "url": "/static/media/02.ec75f7ff.jpg"
  },
  {
    "revision": "8a3fc4d6f94415a9086612a9e1792bba",
    "url": "/static/media/0222.8a3fc4d6.png"
  },
  {
    "revision": "1805c4650980641f238a99fe0816b118",
    "url": "/static/media/03.1805c465.jpg"
  },
  {
    "revision": "5228f5ca38815ab27f6f1764c7c22fb6",
    "url": "/static/media/03.5228f5ca.png"
  },
  {
    "revision": "ccd738c3fc97989cc4ca378f6cb920d0",
    "url": "/static/media/04.ccd738c3.png"
  },
  {
    "revision": "c3a524694cb3ce764c477a469a575350",
    "url": "/static/media/05.c3a52469.png"
  },
  {
    "revision": "4c55977b8ea920f81fa0507564f7cfb6",
    "url": "/static/media/06.4c55977b.png"
  },
  {
    "revision": "2dee806794d9ece9b8e468cdeda389e1",
    "url": "/static/media/3_col_1.2dee8067.jpg"
  },
  {
    "revision": "d55ff2546aa63de7b59b8d81de204d1c",
    "url": "/static/media/3_col_10.d55ff254.jpg"
  },
  {
    "revision": "bddf340d95f9194c062bbe7adfd896bb",
    "url": "/static/media/3_col_11.bddf340d.jpg"
  },
  {
    "revision": "8901bedb374fcf2eaf17ad895a83e355",
    "url": "/static/media/3_col_12.8901bedb.jpg"
  },
  {
    "revision": "facc4a5e0c16942cbfef35f54a63fd96",
    "url": "/static/media/3_col_2.facc4a5e.jpg"
  },
  {
    "revision": "4f5e9d32a43d8195935be77ca52c3b9d",
    "url": "/static/media/3_col_3.4f5e9d32.jpg"
  },
  {
    "revision": "c1ab7ec9ae176c62cb7a29e80b6a9204",
    "url": "/static/media/3_col_4.c1ab7ec9.jpg"
  },
  {
    "revision": "f4e860a46ad4123d17b23280d909f6ea",
    "url": "/static/media/3_col_5.f4e860a4.jpg"
  },
  {
    "revision": "6ba5a5690924162bd95136e0be0fa3e8",
    "url": "/static/media/3_col_6.6ba5a569.jpg"
  },
  {
    "revision": "1e8ee2f578be8e19f66ec572a679f49f",
    "url": "/static/media/3_col_7.1e8ee2f5.jpg"
  },
  {
    "revision": "c7f0b0495ffece1b4757bd19f9d63251",
    "url": "/static/media/3_col_8.c7f0b049.jpg"
  },
  {
    "revision": "7de9c3245a978281563254bb2cf4cf3e",
    "url": "/static/media/ElegantIcons.7de9c324.svg"
  },
  {
    "revision": "d72ad3f702b9f23540e8ed78b4b65749",
    "url": "/static/media/ElegantIcons.d72ad3f7.eot"
  },
  {
    "revision": "f9d179f59b0878ffcd32a5b3c8ae9c62",
    "url": "/static/media/ElegantIcons.f9d179f5.ttf"
  },
  {
    "revision": "fdd9e757bf61675343dcf55100422b84",
    "url": "/static/media/ElegantIcons.fdd9e757.woff"
  },
  {
    "revision": "e6106838d3b83e050ab93db6b41e2aed",
    "url": "/static/media/High-end-all-in-one-dual-screen.e6106838.png"
  },
  {
    "revision": "0bd6650144b8fcc5dfcda3d9663a12c4",
    "url": "/static/media/Img-01.0bd66501.jpg"
  },
  {
    "revision": "6b70b87d803e98b4b9bc7d3780828c32",
    "url": "/static/media/Img-02.6b70b87d.jpg"
  },
  {
    "revision": "5eee01908949ddd6aafd52d1a8b49f82",
    "url": "/static/media/Img-03.5eee0190.jpg"
  },
  {
    "revision": "c20bf45f5b5ff92d8c2a890addeef6c0",
    "url": "/static/media/Img-05.c20bf45f.jpg"
  },
  {
    "revision": "ed7cdcb27f436d74741e560a3ae50e1d",
    "url": "/static/media/Img-07.ed7cdcb2.jpg"
  },
  {
    "revision": "9a6408c7b5ecf23c62c045cc69bf7d09",
    "url": "/static/media/Messages.9a6408c7.jpg"
  },
  {
    "revision": "f3e037309465af0d84e11aa244c7cf3d",
    "url": "/static/media/Messages.f3e03730.png"
  },
  {
    "revision": "73d2b595bd50b2422b90cfce361f021e",
    "url": "/static/media/Prototyping_Tool.73d2b595.jpg"
  },
  {
    "revision": "596814caa4fbaecbf5014bcfe8e363fb",
    "url": "/static/media/Simple-Line-Icons.596814ca.ttf"
  },
  {
    "revision": "c9c9b5ebc6395eeb83072bf18e3818aa",
    "url": "/static/media/Simple-Line-Icons.c9c9b5eb.svg"
  },
  {
    "revision": "f19a7f6c7a0b54b748277c40d7cf8882",
    "url": "/static/media/Simple-Line-Icons.f19a7f6c.eot"
  },
  {
    "revision": "ff94ad94c3a9d04bd2f80cb3c87dcccb",
    "url": "/static/media/Simple-Line-Icons.ff94ad94.woff"
  },
  {
    "revision": "837089ad4dae927f0f89c5663b5b3bed",
    "url": "/static/media/about.837089ad.jpg"
  },
  {
    "revision": "558a04e988e6775d3955f4c27ee6b1ed",
    "url": "/static/media/about_img_1.558a04e9.jpg"
  },
  {
    "revision": "659d831a66475a75148d58662e22ecfd",
    "url": "/static/media/about_img_2.659d831a.jpg"
  },
  {
    "revision": "de946ea60566c3e8291b7dd24720913f",
    "url": "/static/media/action_image.de946ea6.png"
  },
  {
    "revision": "5368732efa0e3abf0ed2ddd1b2112f9a",
    "url": "/static/media/action_img.5368732e.png"
  },
  {
    "revision": "2dbcda6e4f31a843601e0bc9751e6342",
    "url": "/static/media/analytices1.2dbcda6e.png"
  },
  {
    "revision": "29f79406f07118c101a094bdc46c525b",
    "url": "/static/media/analytices3.29f79406.png"
  },
  {
    "revision": "e727677365127fca8615cd2238716dad",
    "url": "/static/media/analytices4.e7276773.png"
  },
  {
    "revision": "4095d26a4f55e10a069c013380edb249",
    "url": "/static/media/analytices5.4095d26a.jpg"
  },
  {
    "revision": "633407d7d9a005610e93917da7d278cf",
    "url": "/static/media/analytices6.633407d7.jpg"
  },
  {
    "revision": "3391fca4151ca4f841c12409675a59a1",
    "url": "/static/media/analytices7.3391fca4.jpg"
  },
  {
    "revision": "5d261e5bbf847e5d93f9c856991060c4",
    "url": "/static/media/analytices8.5d261e5b.jpg"
  },
  {
    "revision": "374ff37bd965d7ff84b05fd51a076015",
    "url": "/static/media/app.374ff37b.png"
  },
  {
    "revision": "5c702f58fd644df5e72c8c0846ad9177",
    "url": "/static/media/app_screen.5c702f58.png"
  },
  {
    "revision": "4ebcf1deec9f681686ef8ecc30d67396",
    "url": "/static/media/b_dashboard.4ebcf1de.png"
  },
  {
    "revision": "0547e8dc117b00f63c37e9c2974c4471",
    "url": "/static/media/background.0547e8dc.png"
  },
  {
    "revision": "399b7b34e0e696aa1cb971356b8a73c9",
    "url": "/static/media/banner.399b7b34.png"
  },
  {
    "revision": "931c1bfa2e94660344b776c5961fba87",
    "url": "/static/media/banner.931c1bfa.png"
  },
  {
    "revision": "ea38f4c618c6b2d11707d168d66e7ec4",
    "url": "/static/media/banner.ea38f4c6.png"
  },
  {
    "revision": "0350ac07dfaf942f06bf28fb50057d62",
    "url": "/static/media/banner_bg.0350ac07.png"
  },
  {
    "revision": "5be017568cba76a1d365d252ac4125ea",
    "url": "/static/media/banner_bg.5be01756.jpg"
  },
  {
    "revision": "378e2312c1c1ddea1c1dc10e73ab2168",
    "url": "/static/media/banner_img.378e2312.png"
  },
  {
    "revision": "bc7e3a14ff5f4fee47281977712c8b25",
    "url": "/static/media/banner_img.bc7e3a14.png"
  },
  {
    "revision": "e96f918ce579cd612a248ceaff95fdfa",
    "url": "/static/media/banner_img.e96f918c.png"
  },
  {
    "revision": "07df75e71906063b10f9df62b4fe0797",
    "url": "/static/media/blog_grid_1.07df75e7.jpg"
  },
  {
    "revision": "09248d2fa1f391a37e577bff0d3a1fab",
    "url": "/static/media/blog_grid_2.09248d2f.jpg"
  },
  {
    "revision": "4d0cc3925587c847d17441e56f427da5",
    "url": "/static/media/blog_grid_3.4d0cc392.jpg"
  },
  {
    "revision": "d94e7cf0a004f152f058ead09c65279f",
    "url": "/static/media/blog_grid_4.d94e7cf0.jpg"
  },
  {
    "revision": "dc59bc48af645592355018a49073f606",
    "url": "/static/media/blog_grid_5.dc59bc48.jpg"
  },
  {
    "revision": "a09386c5b38deecd27e1d7e96cd636b3",
    "url": "/static/media/blog_grid_6.a09386c5.jpg"
  },
  {
    "revision": "f74ea2743f7751706e089c4b4a16ad0e",
    "url": "/static/media/blog_grid_7.f74ea274.jpg"
  },
  {
    "revision": "79c71cd8952e667f44b2e3cc7412f02d",
    "url": "/static/media/blog_grid_8.79c71cd8.jpg"
  },
  {
    "revision": "b2c7920282bb9900eaf3688add8d8655",
    "url": "/static/media/blog_list1.b2c79202.jpg"
  },
  {
    "revision": "20167d95929ea60af5601e3683df7f0d",
    "url": "/static/media/blog_list2.20167d95.jpg"
  },
  {
    "revision": "abb2ebb615098a07ef828efc4574af70",
    "url": "/static/media/blog_list3.abb2ebb6.jpg"
  },
  {
    "revision": "68afa1170ffc7852a2bf870b8bdf3c33",
    "url": "/static/media/blog_list4.68afa117.jpg"
  },
  {
    "revision": "ad855a819e4a97d395c13ba01e1fdef8",
    "url": "/static/media/blog_single.ad855a81.png"
  },
  {
    "revision": "5a62386096e8bad933a2800e864fd573",
    "url": "/static/media/business1.5a623860.png"
  },
  {
    "revision": "23807b69e6ac69e0abebc307457bc089",
    "url": "/static/media/business2.23807b69.png"
  },
  {
    "revision": "d3e330598d81a60a04d702ccb0c54c1f",
    "url": "/static/media/case.d3e33059.png"
  },
  {
    "revision": "8be588ace181db5cf9964243314091a5",
    "url": "/static/media/case_01.8be588ac.jpg"
  },
  {
    "revision": "e403f022cea7ad1509b2ef85af30d7a2",
    "url": "/static/media/case_02.e403f022.jpg"
  },
  {
    "revision": "e1cc4e13e911a1bef7b99a62468450b0",
    "url": "/static/media/case_03.e1cc4e13.jpg"
  },
  {
    "revision": "d43f53b2119f1ab4d0749776cc99bf91",
    "url": "/static/media/case_04.d43f53b2.jpg"
  },
  {
    "revision": "5d03ae50de742c31132257e4d91df2e6",
    "url": "/static/media/case_05.5d03ae50.jpg"
  },
  {
    "revision": "17c849fdb89c8b9c6b9a19541e5e4b09",
    "url": "/static/media/case_07.17c849fd.jpg"
  },
  {
    "revision": "00955b24a4be4fb059ce1a49f9c7b410",
    "url": "/static/media/case_08.00955b24.jpg"
  },
  {
    "revision": "0f803e611524aae254783e6f1d064ffa",
    "url": "/static/media/case_09.0f803e61.jpg"
  },
  {
    "revision": "98e9ec2bf36e52bd58dd68e909ab12c8",
    "url": "/static/media/case_10.98e9ec2b.jpg"
  },
  {
    "revision": "85eed07af0fa9ff65ebec6d40456fa72",
    "url": "/static/media/case_11.85eed07a.jpg"
  },
  {
    "revision": "653dcc267dafae63d2ed736aff14644f",
    "url": "/static/media/case_12.653dcc26.jpg"
  },
  {
    "revision": "c0a1b5c7b0b73bb6f6ea3c2715233e4c",
    "url": "/static/media/case_details_01.c0a1b5c7.jpg"
  },
  {
    "revision": "fad1c41a768b0cedee208a6ecd5f9c52",
    "url": "/static/media/case_details_02.fad1c41a.jpg"
  },
  {
    "revision": "5c06ceaacaa114cc62a053778cbdc839",
    "url": "/static/media/case_details_03.5c06ceaa.jpg"
  },
  {
    "revision": "5ea4c8db84e83c9ee93c2fc564172109",
    "url": "/static/media/chat.5ea4c8db.png"
  },
  {
    "revision": "f0447c9a86d493c55aa2eb1d57c612d1",
    "url": "/static/media/chat_01.f0447c9a.png"
  },
  {
    "revision": "1ba0e87f7a63896c2bd92a6888ea7a5f",
    "url": "/static/media/chat_02.1ba0e87f.png"
  },
  {
    "revision": "d069a2760cdce17af14fe3afea0901af",
    "url": "/static/media/cloud.d069a276.png"
  },
  {
    "revision": "88b1adaa6c89857172e47d38b5d4bc20",
    "url": "/static/media/cloud_bg.88b1adaa.png"
  },
  {
    "revision": "aefaf54902c9cfe48cfc957c7e94d8e2",
    "url": "/static/media/coming_soon_bg.aefaf549.png"
  },
  {
    "revision": "5a657f6f4a2fd16272175ad6a448893c",
    "url": "/static/media/company.5a657f6f.jpg"
  },
  {
    "revision": "9b875bbff75bd1ca2d6b192bd2606496",
    "url": "/static/media/computer_tracking_img.9b875bbf.jpg"
  },
  {
    "revision": "3f8615e1c5020510928f425db414d987",
    "url": "/static/media/contact.3f8615e1.png"
  },
  {
    "revision": "f20c1f62f0cc25b02165fad097f53a1f",
    "url": "/static/media/crismas.f20c1f62.png"
  },
  {
    "revision": "f2bc61c792510f1785e17b221d7ed96a",
    "url": "/static/media/crm_img1.f2bc61c7.jpg"
  },
  {
    "revision": "10ccb40c43cc824b0b27839c20093568",
    "url": "/static/media/crm_img2.10ccb40c.jpg"
  },
  {
    "revision": "9d63a7dca223fe803523e4d435a59279",
    "url": "/static/media/crm_img3.9d63a7dc.jpg"
  },
  {
    "revision": "4bddfbf06bca2bc142c0d8391692121e",
    "url": "/static/media/cta_pattern_bg.4bddfbf0.jpg"
  },
  {
    "revision": "c425e7c96c8c4d079f0f704f2c52f8ac",
    "url": "/static/media/dashboard.c425e7c9.jpg"
  },
  {
    "revision": "e39c7e2942129afdedccd9ab000e2799",
    "url": "/static/media/design1.e39c7e29.png"
  },
  {
    "revision": "07a0e4320f0a29b672b91bd4f2c0f74e",
    "url": "/static/media/design2.07a0e432.png"
  },
  {
    "revision": "e9e91ce4ae4a1e60b4d9af1596e0f457",
    "url": "/static/media/dot.e9e91ce4.png"
  },
  {
    "revision": "83776addb7a1660e0d72adaa4adb9357",
    "url": "/static/media/down_bg.83776add.png"
  },
  {
    "revision": "a9d48cb16c8b6d91654ac7b8e4c85c6f",
    "url": "/static/media/erp.a9d48cb1.jpg"
  },
  {
    "revision": "9aebc27a4f8fc122178e9c1559f7dbd3",
    "url": "/static/media/erp_dashboard.9aebc27a.jpg"
  },
  {
    "revision": "0f4332f2c1400ac974e001bacf2b7907",
    "url": "/static/media/error.0f4332f2.png"
  },
  {
    "revision": "d710f00e93b029cd0d7f93e7dcbc160c",
    "url": "/static/media/error_bg.d710f00e.png"
  },
  {
    "revision": "fd8e07e1348417a2333d639e5779ee73",
    "url": "/static/media/ezgif-1-997e5035cba4.fd8e07e1.png"
  },
  {
    "revision": "4568b5b5034960068b1cd0f69dab2039",
    "url": "/static/media/fa-brands-400.4568b5b5.svg"
  },
  {
    "revision": "cbd387d93e253048800dc9ee22b85c24",
    "url": "/static/media/fa-brands-400.cbd387d9.eot"
  },
  {
    "revision": "d30c44aaad8efa7626428c8294f7e880",
    "url": "/static/media/fa-brands-400.d30c44aa.woff"
  },
  {
    "revision": "d6ac6c968cff1abcbf5d548828b9f6c6",
    "url": "/static/media/fa-brands-400.d6ac6c96.ttf"
  },
  {
    "revision": "eac60e8a656781e13d2a674b4d9051c0",
    "url": "/static/media/fa-brands-400.eac60e8a.woff2"
  },
  {
    "revision": "26d8edc83280c58a277393d469e7b26f",
    "url": "/static/media/fa-regular-400.26d8edc8.svg"
  },
  {
    "revision": "4b218302f9057d02864d4909661831e9",
    "url": "/static/media/fa-regular-400.4b218302.woff2"
  },
  {
    "revision": "8c1f078070537f81237a2e39eaae2555",
    "url": "/static/media/fa-regular-400.8c1f0780.eot"
  },
  {
    "revision": "e32cb360659f3788d9f4b5750c2c5a36",
    "url": "/static/media/fa-regular-400.e32cb360.woff"
  },
  {
    "revision": "f1994ecd58b56afa035ae3da39213357",
    "url": "/static/media/fa-regular-400.f1994ecd.ttf"
  },
  {
    "revision": "2e302fa4c6eeb1bc06149067bae3e7b4",
    "url": "/static/media/fa-solid-900.2e302fa4.eot"
  },
  {
    "revision": "5dc01cfcd5336f696cb85da7ce53fa9b",
    "url": "/static/media/fa-solid-900.5dc01cfc.woff2"
  },
  {
    "revision": "80c404ff42e52d9e7589e83fe21307b4",
    "url": "/static/media/fa-solid-900.80c404ff.ttf"
  },
  {
    "revision": "a8eedaadb16b569a48a061d4aafa2d2e",
    "url": "/static/media/fa-solid-900.a8eedaad.woff"
  },
  {
    "revision": "b7c60297fd4238ed7bf0df6f8842c3df",
    "url": "/static/media/fa-solid-900.b7c60297.svg"
  },
  {
    "revision": "50dceb51f2dcc731e6a0ec2f1690c45c",
    "url": "/static/media/fact.50dceb51.png"
  },
  {
    "revision": "b60ab1ebf82a0a2a794c7e88f8d0d237",
    "url": "/static/media/featured_img.b60ab1eb.png"
  },
  {
    "revision": "86949dc5166b8056f5bef5cddf4c46b0",
    "url": "/static/media/featured_img1.86949dc5.png"
  },
  {
    "revision": "69a639f4e469ebfdb83b4429816cae5f",
    "url": "/static/media/featured_img_one.69a639f4.jpg"
  },
  {
    "revision": "00ba8ada124bb73c6788a19a7990f7e1",
    "url": "/static/media/featured_img_two.00ba8ada.png"
  },
  {
    "revision": "d70e9ad82b69838ba73ad4a5c9894795",
    "url": "/static/media/featured_img_two.d70e9ad8.jpg"
  },
  {
    "revision": "17d53ea5d3429b2aebf306264500d5d6",
    "url": "/static/media/features_01.17d53ea5.png"
  },
  {
    "revision": "21330c43f4bc3f1a7b5c10a81d92362e",
    "url": "/static/media/features_img.21330c43.png"
  },
  {
    "revision": "8b0d25e974b1f1db31076c52fe0ea950",
    "url": "/static/media/features_img_two.8b0d25e9.png"
  },
  {
    "revision": "dae615f0978928a2dbabcd61fe1218f4",
    "url": "/static/media/feedback_shap.dae615f0.png"
  },
  {
    "revision": "316b7b365050bec8214721fecd123413",
    "url": "/static/media/footer_bg.316b7b36.png"
  },
  {
    "revision": "572a3f5839b3a50d2db1adbf49ff4d1d",
    "url": "/static/media/fotter_shap.572a3f58.png"
  },
  {
    "revision": "472c9119d2d3d6eebfec27ef2a3caa46",
    "url": "/static/media/full_1.472c9119.jpg"
  },
  {
    "revision": "5e8f55728841921d5257277e4d91e341",
    "url": "/static/media/full_10.5e8f5572.jpg"
  },
  {
    "revision": "428600567d1af20386f9478ff3e89b3e",
    "url": "/static/media/full_11.42860056.jpg"
  },
  {
    "revision": "00ce4d1178b88d27b047ace0f57b445f",
    "url": "/static/media/full_12.00ce4d11.jpg"
  },
  {
    "revision": "05cd6a6e80840d987ee7a4700ba54ba1",
    "url": "/static/media/full_4.05cd6a6e.jpg"
  },
  {
    "revision": "747a45d4057d89b51a71b0f67c3d5dd5",
    "url": "/static/media/full_6.747a45d4.jpg"
  },
  {
    "revision": "8f1bd4c85b9166619e5d211f65e662ef",
    "url": "/static/media/full_7.8f1bd4c8.jpg"
  },
  {
    "revision": "460a6f61f3641dd26963230df76a323f",
    "url": "/static/media/get_started_bg.460a6f61.png"
  },
  {
    "revision": "9e8e1a2f6144e0101d2a1b4cf6b3d534",
    "url": "/static/media/grid1.9e8e1a2f.jpg"
  },
  {
    "revision": "42e6903ced86969e81dee06cf386e687",
    "url": "/static/media/grid2.42e6903c.jpg"
  },
  {
    "revision": "9dfe9061eab40ee9ae692266bb0836bb",
    "url": "/static/media/grid4.9dfe9061.jpg"
  },
  {
    "revision": "da2ddea84dbe1eea91885853a2a58983",
    "url": "/static/media/grid6.da2ddea8.jpg"
  },
  {
    "revision": "1fd1b96d2cf43739db2335e59cad485c",
    "url": "/static/media/grid7.1fd1b96d.jpg"
  },
  {
    "revision": "c9cfdaa5d866e422fbe0d13ed167b963",
    "url": "/static/media/h_blog1.c9cfdaa5.jpg"
  },
  {
    "revision": "7828a1a17a7f6b90a007f20ba70f7230",
    "url": "/static/media/h_blog2.7828a1a1.jpg"
  },
  {
    "revision": "bfe9ae23e21e0a882f78aca31c5ccf6e",
    "url": "/static/media/home-animation.bfe9ae23.jpg"
  },
  {
    "revision": "5697d4ae435a540aff49880e4b9d2454",
    "url": "/static/media/home-chat.5697d4ae.jpg"
  },
  {
    "revision": "a87a0a3d92f7ecbcdc302e18aa8f4c65",
    "url": "/static/media/home-event.a87a0a3d.jpg"
  },
  {
    "revision": "5b248443234278fd3d57fb50bb8215e5",
    "url": "/static/media/home-security.5b248443.jpg"
  },
  {
    "revision": "55d7ef08a86b8c1c73b847fec3490a29",
    "url": "/static/media/home-track.55d7ef08.jpg"
  },
  {
    "revision": "cbaa76b0a2250d5b9ebf1082de44f42c",
    "url": "/static/media/home1.cbaa76b0.jpg"
  },
  {
    "revision": "9d8ffee3b6f44b09c7517cee97ab8656",
    "url": "/static/media/home10.9d8ffee3.jpg"
  },
  {
    "revision": "bfdcfa2985b9f678df9e4c6d13a128f5",
    "url": "/static/media/home11.bfdcfa29.jpg"
  },
  {
    "revision": "208590a5154c1d4bbcf3823fdc9ae946",
    "url": "/static/media/home12.208590a5.jpg"
  },
  {
    "revision": "349b7aa8bce3125454111414f063c802",
    "url": "/static/media/home13.349b7aa8.jpg"
  },
  {
    "revision": "3f58036181d969f618d78a58fe271eda",
    "url": "/static/media/home14.3f580361.jpg"
  },
  {
    "revision": "ea52bc387921de4fe4301541b20a9417",
    "url": "/static/media/home15.ea52bc38.jpg"
  },
  {
    "revision": "cc5f55dbdffc0f96985aec0d2332dc14",
    "url": "/static/media/home16.cc5f55db.jpg"
  },
  {
    "revision": "d70e86f2687c7e91bbcd0bbd210c56d3",
    "url": "/static/media/home17.d70e86f2.jpg"
  },
  {
    "revision": "04b52f175ed0e216a28431ec92467757",
    "url": "/static/media/home2.04b52f17.jpg"
  },
  {
    "revision": "d6a7b7b0109122e55452894c303219b9",
    "url": "/static/media/home3.d6a7b7b0.jpg"
  },
  {
    "revision": "de4d3783de91cf7cbdfb4fb4c9dd7676",
    "url": "/static/media/home4.de4d3783.jpg"
  },
  {
    "revision": "3f3b452dbff25385228c4677cb8f271a",
    "url": "/static/media/home5.3f3b452d.jpg"
  },
  {
    "revision": "c3a302fa06448f988aa86bd2c4c7b212",
    "url": "/static/media/home6.c3a302fa.jpg"
  },
  {
    "revision": "cfed7f9e45c79adf97a7ba75aecab60c",
    "url": "/static/media/home7.cfed7f9e.jpg"
  },
  {
    "revision": "45ccba2e791febdfd1c90fbb87b552df",
    "url": "/static/media/home8.45ccba2e.jpg"
  },
  {
    "revision": "fc2a1a7829f7ce1f8fa9c1e4be3dbabe",
    "url": "/static/media/home9.fc2a1a78.jpg"
  },
  {
    "revision": "778afe701fa498c59f862dee5ea5a825",
    "url": "/static/media/hosting-image.778afe70.png"
  },
  {
    "revision": "de1eea4bc5c2d295965e8ba1b8c62fdb",
    "url": "/static/media/hosting_action_bg.de1eea4b.png"
  },
  {
    "revision": "6f2f9f37f375293ac6c7e91a2eb81e75",
    "url": "/static/media/iPhoneX.6f2f9f37.png"
  },
  {
    "revision": "ee3f59dc5afb6a7d30240b81ae6ca768",
    "url": "/static/media/iPhoneX2.ee3f59dc.png"
  },
  {
    "revision": "eddfe5aba8b917bb00cb690d092907f3",
    "url": "/static/media/iPhonex.eddfe5ab.png"
  },
  {
    "revision": "5e933b2abe2e1749bf8ffbbd5cb03557",
    "url": "/static/media/image-1.5e933b2a.png"
  },
  {
    "revision": "01cefa13943d67a516ceac11c93d0295",
    "url": "/static/media/image.01cefa13.png"
  },
  {
    "revision": "a30b83fc67289fac4d394fa17b227d34",
    "url": "/static/media/image_01.a30b83fc.jpg"
  },
  {
    "revision": "c951052b2297d00821e6fddd681c462b",
    "url": "/static/media/image_02.c951052b.jpg"
  },
  {
    "revision": "1416845c2e4bc69edd3f99f37ccb5ef2",
    "url": "/static/media/image_03.1416845c.jpg"
  },
  {
    "revision": "bcdcfb4151a302f27e88fa02797ed3bb",
    "url": "/static/media/image_04.bcdcfb41.jpg"
  },
  {
    "revision": "6780d7aad39e6844c7b53e2f7d009cc9",
    "url": "/static/media/image_05.6780d7aa.jpg"
  },
  {
    "revision": "d90f489e024cdbb26bfa52988f10908a",
    "url": "/static/media/image_06.d90f489e.jpg"
  },
  {
    "revision": "8450630b1be1355ca78ab520faf8fa3a",
    "url": "/static/media/instragram1.8450630b.jpg"
  },
  {
    "revision": "b86ebc871adbe1af98f49422e6e57bd5",
    "url": "/static/media/instragram2.b86ebc87.jpg"
  },
  {
    "revision": "6b22e13c93acf01881c35da170073228",
    "url": "/static/media/instragram4.6b22e13c.jpg"
  },
  {
    "revision": "03ea79b2c7733e5fbfba2496db132346",
    "url": "/static/media/instragram6.03ea79b2.jpg"
  },
  {
    "revision": "c7060ab50d136d93dfc30ae919978527",
    "url": "/static/media/item1.c7060ab5.png"
  },
  {
    "revision": "366924ca6fe02d36563bbc652629020c",
    "url": "/static/media/item2.366924ca.png"
  },
  {
    "revision": "d678fa4e1bba92e2123a7b68245b1ef4",
    "url": "/static/media/item3.d678fa4e.png"
  },
  {
    "revision": "b2824f703c663639c6bec2fd62ec3849",
    "url": "/static/media/john.b2824f70.png"
  },
  {
    "revision": "ab491a468f7c6819b17bc40012c660ce",
    "url": "/static/media/laptop.ab491a46.png"
  },
  {
    "revision": "82e3798ffc9853b26104cccac49c3f79",
    "url": "/static/media/laptop_two.82e3798f.png"
  },
  {
    "revision": "d32861d20e931f31539b323cc8ab2b70",
    "url": "/static/media/left_leaf.d32861d2.png"
  },
  {
    "revision": "a2056a5da624f457afd42d3774dada73",
    "url": "/static/media/line_01.a2056a5d.png"
  },
  {
    "revision": "cad6b69b7cb60c8d3d2e7d7043ed4e15",
    "url": "/static/media/line_02.cad6b69b.png"
  },
  {
    "revision": "1d4895e20b49a2d8a681acd2e73c3c4e",
    "url": "/static/media/login_img.1d4895e2.png"
  },
  {
    "revision": "9616595539d885a42ee9ac562f4f0786",
    "url": "/static/media/login_img2.96165955.png"
  },
  {
    "revision": "cd0682a7288ec5946dbbfa957fa7348d",
    "url": "/static/media/mac.cd0682a7.png"
  },
  {
    "revision": "7bc984107faaabfb10fb0e9d5d35d926",
    "url": "/static/media/mackbook.7bc98410.png"
  },
  {
    "revision": "d70305cd9c9fa96bbdec0da3b28db507",
    "url": "/static/media/mackbook.d70305cd.png"
  },
  {
    "revision": "062b76b917f29fd53a7e9a7457c6254c",
    "url": "/static/media/map.062b76b9.png"
  },
  {
    "revision": "bbec67a1f5ff20d3297cdd0912fb5821",
    "url": "/static/media/map.bbec67a1.png"
  },
  {
    "revision": "bc984ba92c5535beb7bb6993f3786bca",
    "url": "/static/media/map.bc984ba9.png"
  },
  {
    "revision": "c7e0222eba28a4cb9b7a559f15734f38",
    "url": "/static/media/month.c7e0222e.png"
  },
  {
    "revision": "9c802a0539d2dff83aa6de8f436a00bd",
    "url": "/static/media/new_shape.9c802a05.png"
  },
  {
    "revision": "7a082c0d71f816ba4a490ddd7250984c",
    "url": "/static/media/p-1.7a082c0d.png"
  },
  {
    "revision": "76ec7b9d2d96a2a1df0113e7cdc766df",
    "url": "/static/media/p-2.76ec7b9d.png"
  },
  {
    "revision": "63e45ade79a8f200096a7a5dec6c3412",
    "url": "/static/media/p_feature1.63e45ade.png"
  },
  {
    "revision": "db60adc44ec5de02d4b2b7e8bc6b24e2",
    "url": "/static/media/php.db60adc4.jpg"
  },
  {
    "revision": "b9d9cb40e71c06bc857d0be88121cd1a",
    "url": "/static/media/pie.b9d9cb40.png"
  },
  {
    "revision": "3867e83437edf0d41e6df83ca913091d",
    "url": "/static/media/pos.3867e834.png"
  },
  {
    "revision": "bc3d9613004d042a88a3c711b5df30f9",
    "url": "/static/media/pos.bc3d9613.jpg"
  },
  {
    "revision": "b39f3517779fe0f31da0f7939aa25a24",
    "url": "/static/media/pos_about_img.b39f3517.png"
  },
  {
    "revision": "436e66322ff9e74f0cf463a251b0d297",
    "url": "/static/media/pos_blog_1.436e6632.png"
  },
  {
    "revision": "1926163b8e6eb47e88d448a99a5f88c9",
    "url": "/static/media/pos_blog_2.1926163b.png"
  },
  {
    "revision": "57dcf0ed7955e76cc7f1129d6ff8352b",
    "url": "/static/media/pos_blog_3.57dcf0ed.png"
  },
  {
    "revision": "33ca4c3a1a85453ad1e79060fdb91701",
    "url": "/static/media/pos_slideshow1.33ca4c3a.jpg"
  },
  {
    "revision": "617e1545cc2bf38f0288b6ce6c3a5592",
    "url": "/static/media/pos_slideshow2.617e1545.jpg"
  },
  {
    "revision": "642110d8fd1a4b3a23dc93e2b6e4de34",
    "url": "/static/media/pos_slideshow3.642110d8.jpg"
  },
  {
    "revision": "2751be0438d46b2f3144c1be9117b20b",
    "url": "/static/media/post_img_1.2751be04.png"
  },
  {
    "revision": "1a465e21b191cd85861778c6d8475d1c",
    "url": "/static/media/post_img_2.1a465e21.png"
  },
  {
    "revision": "fb60556959309df6cf78503816f67f74",
    "url": "/static/media/post_img_3.fb605569.png"
  },
  {
    "revision": "b8070c6b24d9c7a4ca6b4980c97645e7",
    "url": "/static/media/pr_details1.b8070c6b.jpg"
  },
  {
    "revision": "c79e6693b4b039f459cf542ca0229a86",
    "url": "/static/media/pr_details2.c79e6693.jpg"
  },
  {
    "revision": "ca36eeed1d472d0f4139b3150d4ae9da",
    "url": "/static/media/pr_details4.ca36eeed.jpg"
  },
  {
    "revision": "fb692b2f0595b9e357336e13a54be439",
    "url": "/static/media/price_bg.fb692b2f.png"
  },
  {
    "revision": "461bceb0cb74d7d3504932799c7def1c",
    "url": "/static/media/process_1.461bceb0.png"
  },
  {
    "revision": "258617b9f20e45dba49b14bb2ca09b18",
    "url": "/static/media/process_2.258617b9.png"
  },
  {
    "revision": "5d66f9faf4418e9d774486a07922ee91",
    "url": "/static/media/process_3.5d66f9fa.png"
  },
  {
    "revision": "18387428ff99579adfbc6be12f31a62a",
    "url": "/static/media/process_4.18387428.png"
  },
  {
    "revision": "4d57c0e868ca9c68174fd3734b97cc6d",
    "url": "/static/media/process_5.4d57c0e8.png"
  },
  {
    "revision": "ef2d9ab9ac9e938b16742022ff7d65f8",
    "url": "/static/media/promo.ef2d9ab9.jpg"
  },
  {
    "revision": "e4787f25712295d672051168e507c93a",
    "url": "/static/media/prototype_banner_img.e4787f25.png"
  },
  {
    "revision": "37f5848d550803b678885602d143a901",
    "url": "/static/media/prototype_banner_img2.37f5848d.png"
  },
  {
    "revision": "5fee4e2265cb66de9ac19795994ab484",
    "url": "/static/media/region_map.5fee4e22.png"
  },
  {
    "revision": "fadc164d7e01052bea5e12eeee43b679",
    "url": "/static/media/richard.fadc164d.png"
  },
  {
    "revision": "d086a142a04d40e05fca8e714ee9babe",
    "url": "/static/media/rocket.d086a142.png"
  },
  {
    "revision": "2d3ce977abf6283b2f76771f47ecc7d9",
    "url": "/static/media/saas2-slider.2d3ce977.png"
  },
  {
    "revision": "352183753c34df264cb3322c0470ea30",
    "url": "/static/media/screenshot1.35218375.png"
  },
  {
    "revision": "40b40ffe8fe00274611f65a3c53de36f",
    "url": "/static/media/screenshot2.40b40ffe.png"
  },
  {
    "revision": "17eda7dddad458d3a0b6bbd71de3717d",
    "url": "/static/media/screenshot3.17eda7dd.png"
  },
  {
    "revision": "f2bb019a1440130f3cadc0952156f1c8",
    "url": "/static/media/screenshot4.f2bb019a.png"
  },
  {
    "revision": "9be25417b254255858a91d3820ce9beb",
    "url": "/static/media/screenshot5.9be25417.png"
  },
  {
    "revision": "8c3734aeb8d37c45a13c56fe620998a9",
    "url": "/static/media/security_1.8c3734ae.png"
  },
  {
    "revision": "c1a73263c16d2efad7a58eb0b92a2865",
    "url": "/static/media/security_2.c1a73263.png"
  },
  {
    "revision": "c047af1f23a4d960ef402073014805e2",
    "url": "/static/media/security_3.c047af1f.png"
  },
  {
    "revision": "877233faa05be60a4d18930479454ee2",
    "url": "/static/media/security_4.877233fa.png"
  },
  {
    "revision": "50873d73bbacd33183e8721ce9858094",
    "url": "/static/media/service.50873d73.png"
  },
  {
    "revision": "f1fb599c634fd881520479c283e550b4",
    "url": "/static/media/service_details.f1fb599c.png"
  },
  {
    "revision": "50b85aeb243c7f31014842a7a5ce90be",
    "url": "/static/media/service_details_one.50b85aeb.png"
  },
  {
    "revision": "082b727e3c6d8c6c3292fce060c6a739",
    "url": "/static/media/service_item_03.082b727e.png"
  },
  {
    "revision": "1016e70280740c089a32044fec3e80b5",
    "url": "/static/media/setup_img1.1016e702.png"
  },
  {
    "revision": "f9bddd3820249583f7f972a005e23c1d",
    "url": "/static/media/setup_img2.f9bddd38.png"
  },
  {
    "revision": "9f75d8c3bb64a817c1a6e2fb2c868cea",
    "url": "/static/media/setup_img3.9f75d8c3.png"
  },
  {
    "revision": "f23afa97c8d39307375db7dfa33cf15e",
    "url": "/static/media/shap_tecture.f23afa97.png"
  },
  {
    "revision": "ebb79ad7930a3e3ba83cf7d5b0933c5f",
    "url": "/static/media/shape-footer.ebb79ad7.png"
  },
  {
    "revision": "0c9a551f32b87b1abbe4e65cb76816e6",
    "url": "/static/media/shape.0c9a551f.png"
  },
  {
    "revision": "49d71d788158faa35d0c5d65f17c808b",
    "url": "/static/media/shape_bg.49d71d78.png"
  },
  {
    "revision": "67f15a515cb5175dd7d117c72659b25d",
    "url": "/static/media/shape_two.67f15a51.png"
  },
  {
    "revision": "d9026d2c749555b52d2957d6aa71142e",
    "url": "/static/media/sheld_bg.d9026d2c.png"
  },
  {
    "revision": "bd991e1640849d543a1d7299895cc1b6",
    "url": "/static/media/skyp_1.bd991e16.png"
  },
  {
    "revision": "c3b10084bc1f86cd9e97bd488e2d19f5",
    "url": "/static/media/skyp_2.c3b10084.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "c3efe460034305e25444f512984c06c1",
    "url": "/static/media/solution_01.c3efe460.jpg"
  },
  {
    "revision": "3bba8baf38766f61299723667645f345",
    "url": "/static/media/solution_02.3bba8baf.jpg"
  },
  {
    "revision": "f99f361bd58e85f3dc2cdceaeea4da44",
    "url": "/static/media/startup_banner_bg.f99f361b.png"
  },
  {
    "revision": "b143a12c46490825b7e0f05d5a8af715",
    "url": "/static/media/startup_banner_img.b143a12c.png"
  },
  {
    "revision": "ad96aba577f48bfe86b3e80256395903",
    "url": "/static/media/startup_shap.ad96aba5.png"
  },
  {
    "revision": "f501f7e5ce2006ff4fa59967731262ae",
    "url": "/static/media/studies_img_one.f501f7e5.jpg"
  },
  {
    "revision": "2676251b7d3296b7c50763ba8facdc32",
    "url": "/static/media/studies_img_three.2676251b.jpg"
  },
  {
    "revision": "7ad1e9874d01072ba23f497ffb22a721",
    "url": "/static/media/studies_img_two.7ad1e987.jpg"
  },
  {
    "revision": "6591ed8201bcca5319a69f44c0795f4c",
    "url": "/static/media/support_dashboard.6591ed82.jpg"
  },
  {
    "revision": "a989a4a0def7def8719104ff70a11dfe",
    "url": "/static/media/svg.a989a4a0.svg"
  },
  {
    "revision": "7ed5b08c1f505606a8cd31cfddab502e",
    "url": "/static/media/tab.7ed5b08c.png"
  },
  {
    "revision": "940da6e7b77bdea8c27fdac3a57506e1",
    "url": "/static/media/tab.940da6e7.png"
  },
  {
    "revision": "7298b9488cf866c2dc5b88e4e89d9895",
    "url": "/static/media/tab_2.7298b948.png"
  },
  {
    "revision": "2c1eada45ca377349d6848b79fd0e8a5",
    "url": "/static/media/tab_3.2c1eada4.png"
  },
  {
    "revision": "f0823274cf3b883d70592402ed4bfba0",
    "url": "/static/media/tab_shape_bg.f0823274.png"
  },
  {
    "revision": "4ced432d9bde81638a75f4adf10fba0f",
    "url": "/static/media/team1.4ced432d.jpg"
  },
  {
    "revision": "922fca494097f0fa407ff4c28bd46e14",
    "url": "/static/media/team1.922fca49.jpg"
  },
  {
    "revision": "7d50441652e36340f181680612ff6576",
    "url": "/static/media/team2.7d504416.jpg"
  },
  {
    "revision": "ddd51a833cad359105063c02ef1c7ff2",
    "url": "/static/media/team2.ddd51a83.jpg"
  },
  {
    "revision": "37473c560d1ba7133a53e78a636b74ec",
    "url": "/static/media/team3.37473c56.jpg"
  },
  {
    "revision": "2e831ab4a60f69a1b15d564702a9d17d",
    "url": "/static/media/team_01.2e831ab4.jpg"
  },
  {
    "revision": "97e1ae823298c01fe5788ef45a5005cd",
    "url": "/static/media/team_01.97e1ae82.jpg"
  },
  {
    "revision": "6fcd82c7b347d80623243c4f863ef2b3",
    "url": "/static/media/team_02.6fcd82c7.jpg"
  },
  {
    "revision": "705e501fe85f6d9b7d70e6d5d939fd4c",
    "url": "/static/media/team_02.705e501f.jpg"
  },
  {
    "revision": "626d9243ab8139c9e9a9b8c802131789",
    "url": "/static/media/team_03.626d9243.jpg"
  },
  {
    "revision": "a16a7635bf28fe9cb8cbd291e185fff5",
    "url": "/static/media/team_03.a16a7635.jpg"
  },
  {
    "revision": "61cb5983ef321d2c439633c6929e6e12",
    "url": "/static/media/team_04.61cb5983.jpg"
  },
  {
    "revision": "bc3215122051ceb40e73cf870af4ff8f",
    "url": "/static/media/team_04.bc321512.jpg"
  },
  {
    "revision": "560c1136a5d64cddbafb4f4dbf78e8b0",
    "url": "/static/media/team_10.560c1136.jpg"
  },
  {
    "revision": "566edc2bbeca558ed30837e168938c68",
    "url": "/static/media/team_12.566edc2b.jpg"
  },
  {
    "revision": "5cb15fa6599c804c55deda5f97e39158",
    "url": "/static/media/team_5.5cb15fa6.jpg"
  },
  {
    "revision": "aecc8a4937390dc14164169267cf5d28",
    "url": "/static/media/team_6.aecc8a49.jpg"
  },
  {
    "revision": "3352d8e2018866f8e86a69b4d3338686",
    "url": "/static/media/team_7.3352d8e2.jpg"
  },
  {
    "revision": "ff8f0d058fc7a2b97894223cfde27cea",
    "url": "/static/media/team_8.ff8f0d05.jpg"
  },
  {
    "revision": "97e1ae823298c01fe5788ef45a5005cd",
    "url": "/static/media/team_9.97e1ae82.jpg"
  },
  {
    "revision": "3e65fbfbee4c78d90845f30f4f306228",
    "url": "/static/media/testimonial_bg.3e65fbfb.png"
  },
  {
    "revision": "87d0684dab92a92eb702810077756814",
    "url": "/static/media/testimonial_bg_shap.87d0684d.png"
  },
  {
    "revision": "508d6210a3eff3050dffec0fd69c4357",
    "url": "/static/media/testimonial_bg_two.508d6210.png"
  },
  {
    "revision": "99b2de0a56a94578defbdea0ce7915f6",
    "url": "/static/media/testimonial_img.99b2de0a.png"
  },
  {
    "revision": "44fd972fcbfadb458be13b13029cc34c",
    "url": "/static/media/testimonial_img2.44fd972f.png"
  },
  {
    "revision": "2c454669bdf3aebf32a1bd8ac1e0d2d6",
    "url": "/static/media/themify.2c454669.eot"
  },
  {
    "revision": "a1ecc3b826d01251edddf29c3e4e1e97",
    "url": "/static/media/themify.a1ecc3b8.woff"
  },
  {
    "revision": "cba68f986e60df8c74f4a53c3e39595c",
    "url": "/static/media/themify.cba68f98.svg"
  },
  {
    "revision": "e23a7dcaefbde4e74e263247aa42ecd7",
    "url": "/static/media/themify.e23a7dca.ttf"
  },
  {
    "revision": "11022f2031ffded7702aa70fbc205e70",
    "url": "/static/media/ticket-support.11022f20.png"
  },
  {
    "revision": "a6d75cc2b475b7212325a0bff75be256",
    "url": "/static/media/tracking_banner_img.a6d75cc2.png"
  },
  {
    "revision": "8b2cfa2828860a0ef05da7e33d6f6779",
    "url": "/static/media/tree-left.8b2cfa28.png"
  },
  {
    "revision": "08cae884f96fd4e77332d470b69f1967",
    "url": "/static/media/tree-right.08cae884.png"
  },
  {
    "revision": "335959e3d0cca92da76e1d97eb6409a4",
    "url": "/static/media/tree.335959e3.png"
  },
  {
    "revision": "5876f8fe091649f930082fb12807e890",
    "url": "/static/media/triangle_two.5876f8fe.png"
  },
  {
    "revision": "dd10c7b798ceb3df2b1cd237b4fe6458",
    "url": "/static/media/trust_img.dd10c7b7.png"
  },
  {
    "revision": "e0e80a9df98f129b3c0aa5b553430fa1",
    "url": "/static/media/trust_img2.e0e80a9d.png"
  },
  {
    "revision": "7e3e23ce7e0262b5d45133db5c770903",
    "url": "/static/media/undraw.7e3e23ce.png"
  },
  {
    "revision": "1aaf50b99896a5952606ca0cdb6faf06",
    "url": "/static/media/video_bg.1aaf50b9.jpg"
  },
  {
    "revision": "33e069120a1c4e7b3f416a93477c7aa0",
    "url": "/static/media/video_img_01.33e06912.png"
  },
  {
    "revision": "d909bfe08f4c120b557a9edc44e14b46",
    "url": "/static/media/video_img_02.d909bfe0.jpg"
  },
  {
    "revision": "02420317ea8173d2315a0f9c57ed27c1",
    "url": "/static/media/watch_1.02420317.png"
  },
  {
    "revision": "8dd2164a7069b9c3895e6295bfc3cf8f",
    "url": "/static/media/wave_two.8dd2164a.png"
  },
  {
    "revision": "4686b77ff21a8d2a16096734451aff38",
    "url": "/static/media/web_image.4686b77f.jpg"
  },
  {
    "revision": "d0bcd234ee9ded94e23700e994e400fa",
    "url": "/static/media/work1.d0bcd234.png"
  },
  {
    "revision": "bcda33bfcc265ee4fafe42e74cc46838",
    "url": "/static/media/work2.bcda33bf.png"
  },
  {
    "revision": "4197c198efa15f7494f427780ad23dd8",
    "url": "/static/media/work3.4197c198.png"
  }
]);